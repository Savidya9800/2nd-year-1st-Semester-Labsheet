/**
 * 
 */
/**
 * 
 */
module Lab04 {
}