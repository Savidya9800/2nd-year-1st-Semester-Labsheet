package Ex1;

public class Student {
	String studentID;
	String name;
	String degree;
	String mobile;

	private static int max = 100;

	
	public Student(String name, String degree, String mobile) {
		super();
		this.name = name;
		this.degree = degree;
		this.mobile = mobile;
	}

	public static int getNextStudentID() {
		return ++max;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public void print() {
		System.out.println("Student Name :"+getName());
		System.out.println("Student Degree :"+getDegree());
		System.out.println("Student Mobile :"+getMobile());
		System.out.println("Student ID :"+getNextStudentID());
	}

}
