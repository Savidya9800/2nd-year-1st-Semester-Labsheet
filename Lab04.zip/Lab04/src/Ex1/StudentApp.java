package Ex1;

public class StudentApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student[] students = new Student[5];
		
		students[0] = new Student("Savidya", "SE", "0702869800");
		students[1] = new Student("Ovinda", "IT", "0702548796");
		students[2] = new Student("Kasun", "CS", "078985478");
		students[3] = new Student("Bhawi", "CN", "078957846");
		students[4] = new Student("Nipun", "Wd", "0702564879");
		
		for(Student student : students) {
			student.print();
			System.out.println();
		}
	}

}
