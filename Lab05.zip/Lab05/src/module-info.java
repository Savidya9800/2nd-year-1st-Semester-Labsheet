/**
 * 
 */
/**
 * 
 */
module Lab05 {
}