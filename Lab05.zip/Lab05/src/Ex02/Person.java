package Ex02;

public class Person {
	private String name;
	private double basicSal;
	private double otRate;
	private double otHrs;
	private double netSal;
}
