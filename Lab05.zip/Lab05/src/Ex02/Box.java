package Ex02;

public class Box {
	private int length, width, height;
	private int volume;
}
