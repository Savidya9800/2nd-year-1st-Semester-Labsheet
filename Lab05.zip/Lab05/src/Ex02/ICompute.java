package Ex02;

public interface ICompute {
	void calculate(); 
	void display();
	
	
	
}
