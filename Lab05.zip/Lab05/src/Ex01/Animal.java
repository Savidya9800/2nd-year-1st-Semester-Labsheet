package Ex01;

//Class ekak ethule abstract method ekak use karana nisa main class eka 'abstract karanna onee'
abstract public class Animal {
	
	public Animal() {
		System.out.println("Animal Constructor Called");
	}
	
	private String name;

	public Animal(String name) {
		super();
		this.name = name;
	}

	abstract public String speak(); /*{
		return "";
	}*/
	//can't implement this abstract class
	
	public void display() {
		System.out.println("My name is :" + this.name + ". " + this.speak() + ".");

	}
}
