package Ex01;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Animal Animal_1 = new Animal("test");
		//Animal_1.display();
		//Can't create objects in Animal class because, Now Animal class is abstract class
		
		Cat mycat = new Cat("Micky");
		mycat.display();
		
		Dog mydog = new Dog("Rover");
		mydog.display();
		
		ToyCat mytoy = new ToyCat("Kittie", "Toysrus");
		mytoy.display();
		
	}

}
