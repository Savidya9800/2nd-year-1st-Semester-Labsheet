package Ex7;

public class PartTimeStudent extends Student {
	String wHours;

	public PartTimeStudent(String name, String add, String studentId, String wHours) {
		super(name, add, studentId);
		this.wHours = wHours;
	}
	
	public void showDetails() {
		super.showDetails();
		System.out.println("Working Number :" +wHours);
	}
}
