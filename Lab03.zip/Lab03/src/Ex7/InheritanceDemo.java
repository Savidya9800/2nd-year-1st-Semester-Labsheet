package Ex7;

public class InheritanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p1 = new Person("Savidya", "Kurunegala");
		p1.showDetails();
		
		Student s1 = new Student("Bhawi", "Chilaw", "IT22193490");
		s1.showDetails();
		
		PartTimeStudent ps1 = new PartTimeStudent("Ovinda", "Colombo", "IT22114578", "21 Hours");
		ps1.showDetails();
		
	}

}
