package Ex2;

public class Student {
	String name, ditno, add;

	public Student(String name, String ditno, String add) {
		this.name = name;
		this.ditno = ditno;
		this.add = add;
	}

}
