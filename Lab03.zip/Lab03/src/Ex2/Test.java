package Ex2;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1 = new Student("Savidya", "IT22222640", "Kurunegala");
		Student s2 = new Student("Bhawi", "IT22193490", "Chilaw");
		
		System.out.println("Name :" +s1.name+ "\nDitNo :" +s1.ditno+ "\nAddress :" +s1.add+ "\n");
		System.out.println("Name :" +s2.name+ "\nDitNo :" +s2.ditno+ "\nAddress :" +s2.add+ "\n");
	}

}
