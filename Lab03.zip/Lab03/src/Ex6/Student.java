package Ex6;

public class Student extends Person{
	String studentId;

	public Student(String name, String add, String studentId) {
		super(name, add);
		this.studentId = studentId;
	}
	
	//Override the show Details
	public void showDetails() {
		super.showDetails();//Access the showDetails method in Perants class
		System.out.println("My ID is :" +studentId);
	}
	
	
}
