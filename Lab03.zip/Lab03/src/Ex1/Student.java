package Ex1;

public class Student {
	String name, ditno, add;

}
