package Ex9;

public class Pet {
	private String name;
	private String owner;
	private int age;
	
	public Pet(String name, String owner, int age) {
		super();
		this.name = name;
		this.owner = owner;
		this.age = age;
	}
	
	public void showDetails() {
		//System.out.println("\nI am a pet. My name is " +name+ ". My owner is "+owner);
		
	}
}//End of the Pet Class
