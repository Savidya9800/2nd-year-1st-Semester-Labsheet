package Ex9;

public class Cat extends Pet {
	private int livesLeft;

	public Cat(String name, String owner, int age, int livesLeft) {
		super(name, owner, age);
		this.livesLeft = livesLeft;
	}
	
	public void showDetails() {
		super.showDetails();
		//System.out.println("LiversLeft :"+livesLeft);
	}
}//end of the Cat Class
