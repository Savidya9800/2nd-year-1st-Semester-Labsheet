package Ex9;

public class Dog extends Pet{
	private int noOfMasters;
	private String n;
	private String o;
	private String m;

	public Dog(String name, String owner, int age, int noOfMasters) {
		super(name, owner, age);
		this.noOfMasters = noOfMasters;
		
		System.out.println("I am a dog. I have "+noOfMasters+ "masters at home");
	}
	
	public void showDetails() {
		System.out.println("I am a pet. My name is "+n+ ". My owner is "+o)
		;
	}
	
}
