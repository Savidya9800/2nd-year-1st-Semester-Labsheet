package Ex9;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pet p = new Pet("Lissie", "Smith", 3);
		p.showDetails();
		
		Cat c = new Cat("Kyan", "Silva", 4, 4);
		c.showDetails();
		
		Dog d = new Dog("Brown", "Savidya", 5, 1);
		d.showDetails();
	}
}//end of the demo Class
