package Ex3;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1 = new Student();
		Student s2 = new Student();
		
		s1.setName("Savidya");
		s1.setDitno("IT22222640");
		s1.setAdd("Kurunegala");
		
		s2.setName("Bhawi");
		s2.setDitno("IT22193490");
		s2.setAdd("Chilaw");
		
		System.out.println("Name :" +s1.getName()+ "\nDitNo :" +s1.getDitno()+ "\nAddress :" +s1.getAdd()+ "\n");
		System.out.println("Name :" +s2.getName()+ "\nDitNo :" +s2.getDitno()+ "\nAddress :" +s2.getAdd()+ "\n");;
	}

}
