package Ex5;

public class Person {
	String name, add;

	public Person(String name, String add) {
		super();
		this.name = name;
		this.add = add;
	}
	
	public void showDetails() {
		System.out.println("Name :" +name+ "\nAddress :" +add);
	}
}
