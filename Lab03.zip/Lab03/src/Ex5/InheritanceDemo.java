package Ex5;

public class InheritanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p1 = new Person("Savidya", "Kurunegala");
		p1.showDetails();

	}

}
