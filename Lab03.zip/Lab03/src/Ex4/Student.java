package Ex4;

public class Student {
	private String name, ditno, add;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDitno() {
		return ditno;
	}

	public void setDitno(String ditno) {
		this.ditno = ditno;
	}

	public String getAdd() {
		return add;
	}

	public void setAdd(String add) {
		this.add = add;
	}
	
	public String getDetails() {
		String s = "I am a Student. \nMy Name is " +getName()+ "\nI am from " +getAdd()+ "\nMy DitNo is " +getDitno();
		return s;
	}
	
}
