package Ex4;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1 = new Student();
		
		s1.setName("Savidya");
		s1.setDitno("IT22222640");
		s1.setAdd("Kurunegala");
		
		System.out.println(s1.getDetails());
		
	}

}
